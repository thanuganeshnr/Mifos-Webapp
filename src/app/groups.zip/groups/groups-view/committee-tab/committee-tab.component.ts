import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-committee-tab',
  templateUrl: './committee-tab.component.html',
  styleUrls: ['./committee-tab.component.scss']
})
export class CommitteeTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
