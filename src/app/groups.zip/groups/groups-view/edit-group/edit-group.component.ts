import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-edit-group',
  templateUrl: './edit-group.component.html',
  styleUrls: ['./edit-group.component.scss']
})
export class EditGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
