import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-general-tab',
  templateUrl: './general-tab.component.html',
  styleUrls: ['./general-tab.component.scss']
})
export class GeneralTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
