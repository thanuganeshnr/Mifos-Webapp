import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-groups-view',
  templateUrl: './groups-view.component.html',
  styleUrls: ['./groups-view.component.scss']
})
export class GroupsViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
