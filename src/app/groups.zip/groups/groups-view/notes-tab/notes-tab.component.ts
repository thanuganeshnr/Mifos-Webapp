import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mifosx-notes-tab',
  templateUrl: './notes-tab.component.html',
  styleUrls: ['./notes-tab.component.scss']
})
export class NotesTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
